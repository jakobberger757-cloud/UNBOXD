# Signal Taxonomy & Scoring

How to classify, time, weight, and rank what you find, and how to handle the
sensitive-attribute boundary. Read during Phases 3–5.

## Contents
1. Signal types
2. Recency tiers
3. Engagement depth
4. Specificity
5. Confidence
6. The scoring rubric (how to rank)
7. Supersession and conflict resolution
8. Sensitive attributes and gifting guardrails
9. Anti-patterns to avoid

---

## 1. Signal types

Always tag each candidate so facts, observations, and your own reasoning never
blur together:

- **Stated fact** — the person said it themselves, in their words. "I've gotten
  obsessed with bread baking." Highest trust.
- **Observed signal** — public behavior that strongly implies an interest without
  a direct statement. They speak at a woodworking conference three years running;
  they hold a board seat at a wildlife nonprofit. Strong, but a step removed.
- **Inference** — your reasoning from indirect cues. A cap in a photo; a single
  liked post. Useful as a *lead*, never presented as fact, and it must be flagged
  as an inference in the profile.

## 2. Recency tiers

Date every signal and sort it:

- **Current** — within ~6 months. What they're into *now*; weight highest.
- **Recent** — ~6–24 months. Probably still live; weight moderately.
- **Background** — older than ~24 months with nothing fresher. Useful for rapport
  and conversation, but don't build a *current* gift on it.

If a signal is undated, try to date it from the source; if you can't, treat it as
lower-confidence and note the uncertainty.

## 3. Engagement depth

How invested are they, really?

- **Passing mention** — said once, in passing. Weak on its own.
- **Recurring theme** — shows up repeatedly across posts/talks/time. Strong; the
  repetition is the signal.
- **Active practitioner** — they *do* it: joined a club, race results, a home
  studio, a side project, a membership. Strongest — and usually the most
  giftable, because it points to gear, access, or experiences they'll actually
  use.

## 4. Specificity

Always push from category to detail; the detail is what makes a gift land:

- **Generic** — "reads," "into fitness," "sports fan," "likes wine." Low gift
  value on its own.
- **Specific** — the particular author/genre, the specific race they're training
  for, the team, the grape or region, the chess opening, the bike model, the
  cause. Record the detail explicitly — it's the payload.

When you only have the generic category, say so and flag it as a lead to sharpen,
rather than dressing it up.

## 5. Confidence

Rate each entry High / Medium / Low, driven by: source quality (first-person and
on-the-record > third-hand), corroboration (two independent sources > one),
clarity (unambiguous statement > a hint), and signal type (stated > observed >
inferred). A single inferred cue from one photo is Low; a recurring, first-person,
multi-source theme is High.

## 6. The scoring rubric (how to rank)

Rank interests for gift-worthiness by combining four factors:

**recency × engagement depth × specificity × confidence**

Treat it as a practical judgment, not arithmetic. The shape:

- **Top of the list:** current, recurring-or-active, specific, well-sourced. This
  is the dream signal — lead with it.
- **Middle:** strong on some axes, soft on others (e.g., distinctive and specific
  but a bit older, or current but generic). Worth including, with the weak axis
  noted.
- **Bottom / cut:** stale *and* one-off *and* vague *and* low-confidence. Drop, or
  relegate to "open leads."

A useful tie-breaker: a **specific** interest at medium confidence usually beats a
**generic** one at high confidence, because the specific one can actually anchor a
memorable gift. Surface a handful of strong candidates rather than an exhaustive
flat list — the downstream gift step wants signal, not volume.

## 7. Supersession and conflict resolution

When signals conflict, the **more recent one wins**, and the older is demoted to
background rather than deleted:

- **Lifestyle change:** "loved craft beer" (2022) + "two years sober" (2026) → the
  beer interest is dead; sobriety becomes a *gifting guardrail* (avoid alcohol),
  not a profiled trait. Acting on the stale signal here would be actively harmful,
  which is exactly why recency matters.
- **Evolution within a domain:** "ran marathons" (2023) + "first triathlon this
  season" (2026) → endurance sport is current; the *triathlon* is the live,
  specific signal; marathon → background.
- **Location:** old city in a bio + recent geotagged posts in a new city → update
  the context; don't anchor a gift to the old place.
- **Intensity shift:** an interest they used to post about constantly but haven't
  mentioned in two years has likely cooled → demote to background.

When in genuine doubt about which is current, keep both but mark the timeline
clearly and lower confidence; don't silently pick one.

## 8. Sensitive attributes and gifting guardrails

This is the most important boundary in the skill. Re-read the no-go list in
`SKILL.md`. In summary:

**Never infer, label, or record** health or medical conditions, mental-health or
addiction/recovery status, religion, sexual orientation, gender identity,
political affiliation, race or ethnicity, or disability. These are not interests,
they don't serve gifting, and inferring them is both invasive and unreliable.

**The one narrow exception — gifting guardrails.** When a person has *publicly and
unambiguously stated* something that should stop a tone-deaf gift, capture it
**only** as a "things to avoid" constraint:

- Qualifies (record as an *avoid* note): "I'm sober" → avoid alcohol. "I'm vegan"
  → avoid leather, meat, animal products. A stated allergy → avoid that allergen.
  A stated dietary observance → avoid conflicting food/drink.
- Does **not** qualify (leave it out entirely): anything *inferred* ("he hasn't
  posted a drink in a while, maybe he quit"), anything about why ("in recovery
  from…"), or any of the sensitive categories used as a *trait* rather than a
  gift constraint.

The distinction is the whole game: you are recording **a constraint on the gift**
("no alcohol"), never **a fact about the person** ("is in recovery"). Phrase
guardrails as actions to avoid, with the public source, and nothing more. If it
isn't plainly and publicly stated by the person, it doesn't go anywhere in the
profile.

## 9. Anti-patterns to avoid

- **Padding with guesses.** A thin honest profile beats a fat speculative one.
- **Stopping at the category.** "Likes music" is not done; find the genre/artist.
- **Snippet-only profiling.** Read the long-form source before you commit a
  signal; the specific detail is usually buried in the body.
- **Ignoring the clock.** An undated or stale signal treated as current produces
  the worst outcome — a confidently wrong gift.
- **Mixing up two people.** Re-check identity anchors whenever a new source
  introduces facts that don't fit the person you locked in Phase 0.
- **Drifting into the dossier.** If a search is pulling addresses, family, or
  sensitive traits, you've left the purpose behind — stop and refocus on
  interests.
