# Channel Playbook

Tactics for finding a person's interests channel by channel, within the rules.
Read during Phases 1–2. The overarching rule from `SKILL.md` applies everywhere:
**use public information and permitted access; never bypass logins, paywalls,
robots.txt, anti-scraping, or terms of service.** When a channel is walled, route
around it through the search index and alternative public sources.

## Contents
1. The wall problem and how to route around it
2. LinkedIn (highest yield for professionals)
3. The person's own published words (blogs, Substack, articles)
4. Podcasts and video (the marquee source for personal anecdotes)
5. X / Twitter
6. Instagram and Facebook
7. Company bios, team pages, and "fun fact" sources
8. Conferences, talks, and event pages
9. Press, interviews, and profiles
10. Niche and hobby footprints (where "feel seen" specificity comes from)
11. Public photos as low-confidence hints
12. Search query patterns that work

---

## 1. The wall problem and how to route around it

Several of the richest-seeming sources block automated access. This is verified
behavior, not a guess: a direct fetch of a LinkedIn profile returns a
robots-disallowed error, and Instagram/Facebook sit behind login walls. **Do not
try to defeat these.** Bypassing them gets accounts and API keys banned, creates
legal exposure, and yields unreliable data.

What actually works, in priority order:

1. **The search index already saw it.** A web search (e.g.,
   `site:linkedin.com/in "Full Name" company`) frequently returns the person's
   headline, "About" text, location, education, and snippets of recent posts —
   pulled from the public page into the snippet. You get much of the value without
   ever loading the walled page. Mine those snippets hard.
2. **The person's own published material is open.** Articles, talks, podcast
   appearances, personal sites, and conference bios are first-person and freely
   fetchable. This is usually where the *best, most specific* signals live anyway.
3. **Other people wrote it down.** Interviews, event recaps, alumni features, and
   newsletters quote people directly and are fetchable.

"Figure it out when you're blocked" = find another public door. It is never an
instruction to pick a lock.

## 2. LinkedIn (highest yield for professionals)

For a working professional, LinkedIn is the densest single source — but you reach
it through search, not direct fetch.

- Search `site:linkedin.com/in "Full Name"` plus the company or a distinctive
  term. The snippet typically exposes the headline, the **"About" summary**,
  location, and education — and the About section is where people often slip in
  what they care about.
- The **headline and About** frequently carry a personal line ("dad of two,
  marathoner, terrible-but-enthusiastic guitarist"). Treat the self-described
  identity markers as strong stated signals.
- **Recent posts and comments** are public expressions of interest and surface via
  search; what someone repeatedly posts about (a sport, a cause, a builder
  community) is a recurring signal worth weighting up.
- Their **published LinkedIn articles** sometimes have stable, fetchable URLs —
  worth a read for long-form first-person material.
- Do **not** attempt to load the profile through the wall. If the snippet is all
  you can get, that's the source; note it and move on.

## 3. The person's own published words

Often the richest first-person material, and almost always fetchable:

- **Personal site / portfolio / "now" page**, **Substack or other newsletter**,
  **Medium**, a personal blog. Read these in full — a "what I'm into lately" or a
  reading-list post is a goldmine of specific, current signal.
- A newsletter they *write* reveals obsessions directly; one they publicly
  *recommend* is a softer signal.

## 4. Podcasts and video (the marquee source for personal anecdotes)

Long-form audio/video is where people relax and mention the personal stuff — "I
just got back into X," "my whole weekend is Y now." This is the highest-value
content type for "feel seen" specificity, so invest here.

Getting at the content, in order of preference:

1. **Search for an existing transcript or writeup:** `"[Name]" podcast transcript`,
   `"[Name]" "[show name]" transcript`, or `"[Name]" interview` often surfaces a
   published transcript, a write-up, or a quote roundup that's fully fetchable.
2. **Read the show notes / episode description.** These are usually fetchable on
   the show's site, Apple Podcasts, or Spotify, and frequently summarize the
   personal anecdotes and topics covered — sometimes enough on their own.
3. **Mine quotes elsewhere.** Reporters and bloggers quote podcast guests; those
   articles are fetchable and date-stamped.
4. **YouTube:** read the video description and pinned/visible info; search for the
   episode's transcript or recap. (Auto-captions are not reliably fetchable
   directly — don't fabricate a transcript you couldn't actually read; work from
   show notes, writeups, and confirmed quotes, and set confidence accordingly.)

When you do read a transcript or writeup, pull the *specific* detail and the
date — "took up sea kayaking last summer" beats "likes the outdoors."

## 5. X / Twitter

- Public posts and the bio surface via search (`"[Name]" site:x.com`, or search
  their handle once you've confirmed it's theirs). The **bio** and a **pinned
  post** are deliberate self-presentation — strong signals.
- Look for *recurring themes* across posts rather than one-offs; a repeated topic
  is a real interest, a single retweet usually isn't.
- Don't rely on sketchy third-party mirror sites; prefer the search index and
  genuinely public content.

## 6. Instagram and Facebook

Both are largely walled, so calibrate effort to yield:

- **Instagram:** public creator/business accounts are sometimes indexed; the
  **bio**, and **captions/hashtags** can surface via search. A public account's
  bio often states interests plainly. Don't log in or bypass the wall.
- **Facebook:** mostly private; only public Pages / public-figure pages are
  reachable, and yield is low for most people. Don't push on it, and never try to
  view private content.
- For both, the **profile photo** is sometimes visible publicly — see §11 for how
  to use it as a *low-confidence* hint only.

## 7. Company bios, team pages, and "fun fact" sources

Disproportionately high-yield and fully fetchable. Many firms put a deliberate
personal line in team bios precisely so people seem human:

- The **company "About the team" / leadership page** — look for an "outside of
  work," "when not working," or **"fun fact"** line. These are *handed to you* and
  are explicit, current, stated interests.
- **Speaker bios** on conference and webinar pages (see §8) often include the same
  personal hook.
- Award write-ups, "40 under 40" features, and association member spotlights
  routinely include a hobbies line.

## 8. Conferences, talks, and event pages

- **Speaker/panelist bios and session titles** reveal professional passions and
  sometimes a personal hook; fetchable.
- A recurring speaking topic across years signals genuine, durable interest.
- Event recaps and the person's own "great to speak at X" posts add recency.

## 9. Press, interviews, and profiles

- Trade press, local news, **alumni magazine** features, and Q&A-style interviews
  are long-form, first-person, and fetchable — excellent for specific anecdotes
  ("she restores vintage Vespas on weekends").
- Alumni features in particular often dwell on personal passions and origin
  stories.

## 10. Niche and hobby footprints (where "feel seen" specificity comes from)

This is the layer that turns a generic profile into a gift that lands. Check the
ones that fit the signals you're already seeing — don't blanket-search all of them:

- **GitHub** — public repos and side projects reveal technical passions and what
  someone builds for fun.
- **Endurance sport** — public **race-result databases** (marathon/Ironman/Parkrun
  finisher pages), **Strava** public clubs/segments, cycling event results. These
  confirm an *active* sport and often the specific discipline.
- **Reading / film / games** — Goodreads or StoryGraph (books + genres),
  Letterboxd (film), BoardGameGeek, public Chess.com / Lichess profiles, Discogs
  or last.fm (music taste).
- **Food & drink** — public review profiles can reveal cuisines and favorites.
  Note the **guardrail interaction**: a beer-rating profile is an interest signal
  *only* if there's no contradicting, more-recent sobriety statement (see the
  taxonomy on supersession).
- **Community & cause** — Meetup groups, nonprofit **board memberships**,
  volunteering, alumni associations, professional societies. Causes someone gives
  time to are deeply held interests.
- **Reddit / forums** — only if a handle is *clearly public and clearly tied to
  this person* (e.g., they link it themselves). Do **not** try to deanonymize
  someone or connect a pseudonymous account to them by inference; that crosses
  from research into something invasive.

## 11. Public photos as low-confidence hints

Visual cues from **public** images can suggest interests — a team cap or jersey, an
instrument in the background, ski or climbing gear, a recognizable race bib, a
specific dog breed. Use these as *hints to confirm*, never as standalone
conclusions:

- A Mets cap suggests Mets fandom → log as a **low-confidence** lead and try to
  corroborate (a post, a bio line). If corroborated, it graduates; if not, it
  stays a soft hint.
- Only ever use publicly visible photos, and only for benign interest signals —
  never to infer location, who they live with, or any sensitive characteristic.

## 12. Search query patterns that work

- Identity & disambiguation: `"Full Name" "Company" title`
- LinkedIn route-around: `site:linkedin.com/in "Full Name" company`
- Their own writing: `"Full Name" substack OR blog OR "I wrote"`
- Podcasts/interviews: `"Full Name" podcast transcript` · `"Full Name" interview`
- Company fun fact: `"Full Name" "Company" team OR bio OR "fun fact"`
- Speaking: `"Full Name" conference OR panel OR keynote 2026`
- Hobby footprints: `"Full Name" marathon OR strava OR goodreads OR github`

Run these as *separate* targeted searches and follow promising results with a full
fetch. One distinctive term per query beats a long combined query. Always capture
the source URL and a date for anything you'll cite.
