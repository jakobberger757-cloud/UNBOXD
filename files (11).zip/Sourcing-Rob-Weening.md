# Sourcing — Rob Weening (Highcrest Capital)

**Band / compliance:** modest, tasteful, compliance-aware (private-credit fund CFO)
**Recipient location:** Fredericksburg, TX (Hill Country)
**Unknowns carried in:** *fly vs. bass fishing* and *does he drink* — sender doesn't know either → **both handled by hedging (option-preserving buys), not guessing.**

---

## Idea 1 — A guided fishing morning (the strategy's top pick)

### Recommended
- **The specific buy:** Lone Star Fly Fishing — **Guadalupe River Half-Day Trip Gift Certificate**.
- **Vendor / where:** Lone Star Fly Fishing, New Braunfels TX (lonestarflyfishing@yahoo.com · 281-382-2871). Established Hill Country guide service that lives on the river; strong, specific reputation.
- **Price (verified):** **$400.00**, in stock. Rate covers **1 or 2 anglers**; excludes gratuity; reschedulable up to 10 days out; **expires 1 year**.
- **How it handles the unknown:** this outfitter guides **both trout (fly) on the Lower Guadalupe AND bass/striper on the Upper Guadalupe** — so a gift certificate lets *Rob* pick the species, water, and season. "Fly vs. bass" never has to be answered. (Bonus: their Upper-Guadalupe bass water runs near Comfort/Boerne, ~40 min from Fredericksburg; the Lower-Guad trout stretch is a bit further but theirs to arrange.)
- **Delivery / presentation:** **emailed/printable gift certificate — no home address needed**; Rob contacts them to schedule. *Or* the higher-touch play: **offer to book it and go together** (turns it into a shared half-day, not a mailed gift). The strategy's note travels in the certificate email: *"Heard the Hill Country's been the new adventure since you and Susan put down roots — figured its rivers deserved a proper introduction. Tight lines."*
- **Link (verified):** https://www.lonestarflyfishing.com/shop/half-day-guided-fishing-trip-1
- **⚠️ Flag — price vs. compliance:** **$400 sits at/above the common B2B gift ceiling** (~$100–$250 in many codes; broker-dealers $100/yr). Before sending, either: (a) lean on the *"take him" framing*, which reframes it as a shared business outing rather than a gift; (b) confirm Highcrest's gift-acceptance limit; or (c) if a hard cap applies, drop to the safe-pick gear below or the give-back. **Don't assume it clears — check.**

### Backup
- **All Water Guides** — Guadalupe River float trips; **2025 Orvis-endorsed Outfitter of the Year** (prestige/quality signal), licensed/insured guides, gear included. Good if you want a marquee name. (Guadalupe trout is cold-months only with them.) https://www.allwaterguides.com/guadalupe-river
- **Expedition Outfitters** — explicitly offers **fly *and* conventional-tackle** trips across Hill Country rivers — the most literal hedge if you'd rather the "both" be on the label.

### Season note
Guadalupe **trout** is stocked Nov–Mar (cold months); **bass** fishes spring–fall. The flexible certificate means Rob picks the trip that matches the season — another reason the voucher beats a fixed booking.

---

## Idea 2 — A Hill Country food experience (the "you-and-Susan" pick)

### Recommended
- **The specific buy:** **Cabernet Grill eGift card** (sender chooses the amount).
- **Vendor / where:** Cabernet Grill — Texas Wine Country Restaurant, Fredericksburg (Cotton Gin Village; Chef Ross Burtwell). **Fredericksburg's #1 restaurant on TripAdvisor**, 4.7★ / 2,300+ Google reviews — Certified Angus Beef, fresh seafood, a landmark spot.
- **Price (verified):** sender sets the denomination — so **size it to the compliance band** (e.g., $100–$150 keeps it under common caps). eGift **does not expire**; redeemable only at the restaurant; **not redeemable for cash** (so it's a venue gift, not a cash-equivalent).
- **How it handles the unknown:** a restaurant gift card is **food-forward** — Rob uses it for the meal, with wine entirely *his* option. It does **not** presume he drinks, which sending a bottle would. And it's naturally a **couple's** gift for him and Susan (food + travel + wine country, all in their new backyard).
- **Delivery / presentation:** **eGift sent by text or email — no address needed**, can be scheduled. Note goes in the message. (Physical card by phone: 830.990.8381.)
- **Link (verified):** https://www.cabernetgrill.com/store/p3/Gift_Cards.html
- **⚠️ Skill flag — avoid the cash-equivalent version:** there's a "Giftly" Cabernet Grill card that lets the recipient **convert to cash / PayPal / a Visa card** — that's a cash-equivalent and a **compliance red flag**. **Use the restaurant's own venue-locked eGift, not Giftly.**

### Backup / fully alcohol-free alternative
- **Das Peach Haus (Fischer & Wieser), Fredericksburg** — a **cooking class** or a **curated box of Hill Country provisions** (jams, sauces, salsas). Food-centric, **zero alcohol** (sidesteps the drink question entirely), and a literal "taste of the new neighborhood." Cooking class is experiential; the provisions box is shippable. (Verify current class schedule/price at booking.)

---

## Compliance reminder (surface to the sender)
- This sources to a **defensible, tasteful** band — but **check both parties' gift policies** before sending. The fishing certificate is the one to scrutinize on value; the restaurant eGift is easy to size under a cap.
- No cash-equivalents recommended (and one to actively avoid — see the Giftly flag). Nothing timed onto a pending decision.

## This is the procurement step
Deciding *what to give and why* was the Gift Strategist step. This step made it real: specific vendors, verified prices and links, how it gets to Rob without his home address, and backups. The only remaining judgment calls are the compliance ceiling and whether you'd rather **gift the trip or take him on it.**
