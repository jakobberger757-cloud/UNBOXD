# Sourcing & Verification

How to find the real, buyable thing — near the recipient, reputable, in budget,
and actually available. Read during Phases 1–4.

## Contents
1. The option-preserving toolkit (handling open variables)
2. Finding candidates near the recipient
3. Verifying price (get the *current* number)
4. Verifying availability, lead time, and season
5. Vetting vendor quality and authenticity
6. Link discipline

---

## 1. The option-preserving toolkit (handling open variables)

When the strategy carries an unknown the sender can't resolve, pick a buy that
makes the unknown *not matter*. In rough order of how much it preserves choice:

- **Flexible / tailored experience** — an outfitter, studio, or venue that
  accommodates either answer, with the specifics set on the day. (Fishing guide
  who runs both fly and conventional trips; a cooking class that adapts; a tasting
  that can be food-only.)
- **Gift certificate to one *specific, vetted* place** — keeps the choice with the
  recipient while staying precise about *where*. The thoughtfulness lives in the
  curation of the venue, not in forcing the variable. (A credit to a single
  excellent local outfitter or restaurant reads as personal; a generic
  marketplace card does not — see anti-generic in the strategy skill.)
- **A robust object** — gear or goods that any practitioner of the hobby uses
  regardless of sub-style; a food-forward item that doesn't hinge on alcohol.
- **Clean branch** — when no single option covers both cases, present "if A →
  this; if B → that," each pre-verified, so the sender acts instantly once they
  learn the answer.

Only resolve by research when the variable is genuinely discoverable and worth the
effort. Private taste usually isn't — hedge instead of inventing a fact.

## 2. Finding candidates near the recipient

Location is decisive for experiences, dining, and local goods — they must be near
**the recipient**, not the sender.

- Anchor searches on the recipient's city/region (e.g., "fly fishing guide
  Fredericksburg / Hill Country", "best tasting-menu restaurant Fredericksburg").
- Use **place / map lookups** to surface real, nearby, well-rated venues with
  hours, ratings, and contact details — then confirm specifics on the venue's own
  site.
- Prefer **authentic local operators** (a real area guide service, a destination
  restaurant) over national chains or generic gift portals — authenticity is part
  of the "tasteful" bar.
- For shippable objects, location matters less, but check that the vendor ships to
  the recipient's region and in time.

## 3. Verifying price (get the *current* number)

The strategy gave a band; sourcing must produce a real figure.

- Pull the **current price** from the vendor's own page or a current listing — do
  not rely on a remembered or estimated number.
- Capture what the price *includes* (e.g., a guided trip: gear, license, hours,
  number of guests) so the comparison to the band is honest.
- Convert the band into a yes/no: does the real number sit inside budget **and**
  under the compliance ceiling? If it's over, downgrade (shorter session, smaller
  format) or switch to the backup.

## 4. Verifying availability, lead time, and season

A perfect gift you can't actually get in time is a miss.

- **Stock / bookability:** is the item in stock, or the experience taking
  bookings? Seasonal experiences (fishing runs, harvest-season tastings) may be
  time-bound — note the window.
- **Lead time:** shipping/delivery estimate, or how far ahead the experience books
  up. Map it against any occasion/deadline.
- **Redemption window:** for vouchers/certificates, note expiry and how the
  recipient redeems.

## 5. Vetting vendor quality and authenticity

The vendor is part of the gift. Before recommending:

- Check **reputation** — reviews/ratings, an established presence, signs it's a
  real, well-regarded operator rather than a drop-shipper or tourist trap.
- Check **quality fit** — does it match the "tasteful, will-impress" bar the
  strategy set? A cheap-looking version of the right idea still misses.
- Check **legitimacy** — a real site, real contact info, secure checkout; avoid
  anything that looks like a scam or counterfeit.

## 6. Link discipline

Sourcing is the step where real links belong — but:

- Provide only links you've **actually confirmed** resolve to the right product or
  venue. **Never fabricate a URL** or guess a product page.
- Prefer the **vendor's own page** (the outfitter, the restaurant, the maker) over
  aggregators where possible.
- If you can name the exact vendor but can't verify a live product link, say so
  and give the vendor name + how to reach them rather than a made-up link.
