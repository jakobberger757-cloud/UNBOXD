# Interest Profile — Robert "Rob" Weening

**Role / Company:** Chief Administrative Officer & CFO, Highcrest Capital, LLC — a small (~11–13 person) alternative-investment / private-credit fund in Fredericksburg, TX (anchor product: the Highcrest Private Credit Income Fund).
**Identity anchors:** CAO/CFO at Highcrest; based in Fredericksburg, TX; married ~30 years to wife **Susan**; relocated CA→TX (~2020) to be near family; Wagner College (Cum Laude) + Pace University MBA; prior FinTech CFO roles (Velocity Commercial Capital, QuickBridge, GHS Interactive Security). *These anchors matter — see the disambiguation note.*
**Researched:** May 29, 2026 · **Sources reviewed:** Highcrest team page, Equilar exec bio, multiple firm/aggregator listings · **Overall confidence:** Medium–High (strong firm-authored interest signal; limited *fresh* confirmation)

---

## Top interests (ranked, gift-ready)

**1. Fishing**
- Evidence: "Outside of the office, Rob enjoys the outdoors especially fishing and shooting sports." — Highcrest "People" page / Equilar bio
- Type: stated fact (firm-authored) · Recency: from firm bio (~2020), durable interest · Engagement: stated personal enjoyment (depth not public) · Specificity: "fishing" — discipline (fly / spin / fresh vs. salt) not stated · Confidence: **High** that he fishes; Medium on current intensity
- Possible angle: a guided fishing experience or premium gear — the Hill Country's Guadalupe River is noted fly-fishing water. *(Gift selection is a separate step.)*

**2. Shooting sports**
- Evidence: same sentence — "...especially fishing and shooting sports."
- Type: stated fact · Recency/durability: as above · Specificity: "shooting sports" — clays / skeet / hunting / target not stated · Confidence: **High / Medium**
- Possible angle: a sporting-clays outing at a Hill Country club, or quality range accessories.

**3. World travel & food adventures (with Susan)**
- Evidence: "Married for 30 years, Rob and Susan share a love of world travel and food adventures." — firm bio
- Type: stated fact (shared with spouse) · Recency: bio (~2020), durable couple's interest · Specificity: travel + dining; destinations/cuisines not stated · Confidence: **High**
- Possible angle: a standout culinary experience or travel/food-themed gift. Note Fredericksburg sits in Texas Hill Country wine country with a strong food scene — a local food/wine experience could hit travel + food + place at once.

**4. Exploring the Texas Hill Country / Fredericksburg outdoor life**
- Evidence: "...thrilled to spend time exploring the Texas hill country and planting roots in Fredericksburg." — firm bio
- Type: stated fact · Recency: tied to the ~2020 move; current lifestyle · Specificity: regional outdoor exploration · Confidence: **High**
- Possible angle: a Hill Country experience (wine country, outdoor recreation) — overlaps with #1 and #3.

**The synthesis worth noting:** these stack into one coherent picture — an outdoorsman (fishing + shooting) who loves food and travel and is putting down roots in Hill Country wine-and-food country. A gift that *blends* the outdoors with food/wine in his own backyard would read as genuinely seen, versus a generic finance-exec gift.

---

## Gifting guardrails — things to AVOID
- **None identified.** No publicly stated dietary restriction, sobriety, allergy, or similar surfaced.

---

## Background / past interests (rapport, not gifting)
- 30+ year finance/accounting career; ~2008–2020 as a FinTech CFO in California (small-balance commercial real estate & working-capital lending) before the Texas move.
- Born Staten Island, NY; Wagner College (Cum Laude, B.S. Economics & Business Administration); MBA in International Finance, Pace University.
- Married ~30 years to Susan; relocated to be closer to family. *(Conversation fuel, not a gift basis.)*

---

## Open leads to verify (would sharpen a gift)
- **Discipline specifics:** type of fishing (fly / spin / fresh / salt) and shooting sport (sporting clays / skeet / hunting / precision).
- **Travel & food specifics:** favorite destinations or cuisines.
- **Currency check:** the strong signal comes from a firm bio of ~2020 vintage; no fresh (2025–26) public post surfaced to confirm these are still active. They're durable interests, so likely current — but treat "still doing it today" as probable, not confirmed.

---

## Disambiguation note (important)
- There is at least one **other "Rob Weening" in Fredericksburg, TX** — a retired information architect / aquaponics hobbyist (separate LinkedIn profile). Do not attribute his details to the CFO.
- His Highcrest colleague **John Ogle** is the one publicly into hunting, fly fishing (and ice fishing) and Columbia basketball — keep those separate from Rob.

---

## Sources
- **Highcrest Capital "People" page** (firm-authored bio) — interests + background — highcrestcapital.com/index.php/people/
- **Equilar ExecAtlas bio** (reproduces the firm bio) — interests, education, background — people.equilar.com/bio/org/highcrest-capital-llc/10045567
- **Firm/aggregator listings** (RocketReach, ZoomInfo, Crunchbase, Crustdata) — used only to confirm role, firm size, and location

*Excluded by design:* personal emails, phone numbers, and home street address surfaced on data-broker sites were deliberately left out — they don't serve gifting and sit on the skill's no-go list.
