# Impact Playbook

How to maximize the "how did they know?" reaction. Read during Phases 3–6.

## Contents
1. The five levers, in depth (and how to score them)
2. The gift-archetype catalog
3. The craft of the accompanying note
4. Quick scoring worksheet

---

## 1. The five levers, in depth

Score each candidate idea on these. The best ideas pull several at once;
**synthesis + an experience** is the most reliable combination for delight.

**Precision — does it map to a specific, named detail?**
The whole game. "Likes wine" is a category; "is putting down roots in a famous
wine region" is a detail. Push every idea to the most specific true thing you
have. Score High if a stranger reading the gift could guess the exact interest;
Low if it fits any executive.

**Synthesis — does it connect two or more signals?**
The strongest single move. When a gift is simultaneously about their hobby *and*
their location, or their passion *and* their partner, it proves someone was
paying real attention, because nobody expects their separate interests to be
linked. Actively look for two signals that fold into one gift. Score High for a
genuine multi-signal fit, Medium for one strong signal, Low for a stretch.

**Effort cue — is the thought visible?**
Impact is partly about the *evidence of care*, and most of that evidence lives in
the **note** (section 3) and in choosing something that clearly isn't off-a-shelf.
A gift that looks like it took thought outperforms an objectively nicer gift that
looks defaulted. Score by: does the note name the specific thing? Did the choice
require knowing them?

**Usability — will it enter their actual life?**
A gift they'll *use* keeps paying off and signals you understood how they really
spend time. Weight **active practice** ("joined a club," "races," "has a studio")
above **aspiration** ("said they want to try"). Aspirational gifts are riskier —
they can read as a comment ("you should do more of this"). Score High for an
active-practice fit, lower for aspirational or display-only.

**Tasteful surprise — is it elevated, rare, or experiential — without excess?**
The "I'd never buy this for myself" delight. Experiences, hard-to-find items, and
a notch-above version of their everyday gear all qualify. The ceiling is set by
the constraints file: surprise that tips into *lavish* backfires in B2B. Score
High for memorable-but-appropriate; penalize anything that strays toward
extravagant or obligating.

**A useful tie-breaker:** a *specific* idea at medium confidence beats a *generic*
idea at high confidence. The specific one can actually produce the reaction;
the generic one never will.

---

## 2. The gift-archetype catalog

Generate across these rather than five variants of one object. Each has a moment
where it shines.

**Experience** — a guided outing, a lesson, a tasting, tickets, a class.
- Shines when: the interest is something they *do*; you want maximum memorability;
  you want to include a partner. Often the highest-impact and hardest to re-gift.
- Example: angler → a guided trip on water they love; food lover → a chef's-counter
  or tasting experience.

**Elevated version of their thing** — the premium or beautiful version of gear or
a tool they already use.
- Shines when: they're an active practitioner with everyday equipment you can
  upgrade tastefully.
- Example: a handcrafted fly box; a precision tool for a hobby; a beautiful edition
  of a thing they use daily.

**Curated / hard-to-find object** — a signed book, a limited or artisan item, a
piece tied to a specific niche of the interest.
- Shines when: the interest is intellectual or has a canon (authors, makers,
  history) and you can hit the *specific* sub-interest.
- Example: a signed copy by an author they referenced; an artisan piece from a
  maker in their field.

**Consumable tied to taste** — a specific food or drink they're known to love.
- Shines when: there's a clear, current taste signal *and no guardrail against it.*
- Caution: never assume alcohol; "loves food" ≠ "drinks." Confirm or choose a
  food-forward option. Re-check guardrails here first.

**In-their-backyard / local** — something rooted in their city, region, or
community, especially if they recently moved or clearly love the place.
- Shines when: place is itself a signal ("exploring the Hill Country," "born and
  raised in…"). Doubles as synthesis when combined with a hobby.
- Example: a standout experience or curated provisions from their region.

**Give-back** — a donation or membership to a cause they care about, made in their
name.
- Shines when: a genuine cause/affiliation surfaced; or when budget/compliance
  rules out objects and you want something classy and safe. Lower raw "wow," high
  class, zero compliance risk.
- Example: a membership to a conservation group for an outdoors lover; a gift to a
  cause they publicly support.

**Handmade / personal** — something curated or assembled specifically for them (a
small, well-chosen kit; a personalized item).
- Shines when: you want the effort cue at maximum and the budget is modest.
- Caution: keep it tasteful and not over-familiar for professional relationships.

---

## 3. The craft of the accompanying note

The note carries up to half the impact, because it's where the **effort cue**
becomes explicit. The gift makes the point; the note lands it.

**Principles:**
- **Name the specific thing — once.** "Heard you've gotten into X" makes the
  connection unmissable. That single specific reference is the whole trick.
- **Be short.** Two or three sentences. A long note dilutes; a tight one feels
  confident.
- **Warm, not transactional.** It's a gesture, not a touchpoint. Don't attach an
  ask, don't mention the deal, don't "look forward to the next steps."
- **Don't narrate the research.** "I saw on your company bio that…" is faintly
  creepy and breaks the spell. Imply you simply *know* them. ("Figured the river
  deserved a proper introduction" — not "Your Equilar profile says you fish.")
- **Match the register** to the relationship — a hair more formal for a prospect,
  warmer for an established one.

**Shape that works:** a specific reference → the gift's connection to it → a warm,
light sign-off. Example: *"Heard the Hill Country's been the new adventure since
the move — figured its trout deserved a proper introduction. Enjoy. — [Name]"*

**Avoid:** generic ("Hope you enjoy this little something!"), research-revealing,
or anything with a business ask stapled on.

---

## 4. Quick scoring worksheet

For each candidate, jot:

- Maps to signal(s): __________  → feel-seen test: pass / fail
- Levers pulled: precision · synthesis · effort · usability · surprise
- Hard-constraint check: guardrails ✓ · value/appropriateness ✓ · dignity ✓ ·
  recency/confidence ✓ · not-generic ✓
- Archetype: __________
- Note drafted: __________
- Verdict: top pick / safe / bold (⚠️ risk: ____) / give-back / cut

Rank by levers pulled (synthesis-bearing ideas first), break ties toward
specificity, and present the shaped shortlist from the SKILL.md output schema.
