# Appropriateness & Constraints

How to keep a high-impact gift from backfiring. Read during Phases 1–2 and again
before finalizing. In professional contexts these aren't fine print — a gift that
breaks them does active damage.

## Contents
1. Why appropriateness *is* impact
2. Relationship calibration
3. Occasion & timing
4. Value bands and B2B compliance
5. The dignity / not-too-intimate line
6. The disqualifier checklist

---

## 1. Why appropriateness *is* impact

A gift that's too expensive, too intimate, or badly timed doesn't just score
lower — it produces the opposite of delight. The recipient may have to decline it,
log it with compliance, wonder what you want, or feel watched. "Tasteful and
dead-on" beats "lavish" every single time, and the constraints below are how you
stay tasteful while still landing the "how did they know?"

## 2. Relationship calibration

Who's sending sets both the tone and the ceiling:

- **Vendor → prospect / client (the default B2B case):** keep it modest,
  defensible, and clearly a relationship gesture. Lean toward shared experiences
  and thoughtful small items over expensive objects. Never let it look like it's
  buying a decision. The more regulated the recipient, the more conservative.
- **Peer / colleague:** warmth is fine; keep value reasonable and avoid anything
  that reads as over-familiar.
- **Manager → report (or vice versa):** thoughtful but neutral; avoid anything
  personal-life-intimate or status-laden.
- **Founder → investor / partner:** taste and specificity matter more than spend;
  over-spending can read as insecure.
- **Friend / personal:** the ceiling on intimacy and budget relaxes — most B2B
  rules below don't apply, though the dignity test still does.

## 3. Occasion & timing

- **Match the gesture to the moment:** first touch (light, no pressure),
  thank-you, closed deal / milestone (can be a touch more substantial),
  holiday, or no occasion at all (relationship warming — often the most genuine).
- **Do not time a gift on top of a live decision.** A gift that arrives while a
  contract, vote, or selection is pending reads as influence-buying, even if it
  isn't. Wait until after, or send it untethered from the decision.

## 4. Value bands and B2B compliance

Treat value as a constraint, not a dial to maximize. General guidance — **verify
for the specific parties; this isn't legal advice:**

- **Default modest.** A tasteful, well-aimed gift in a modest range outperforms an
  expensive one and avoids policy problems. When unsure of the ceiling, go lower.
- **Common policy limits exist and are often low.** Many corporate codes of
  conduct cap gifts (frequently around the $100–$250 range); broker-dealers operate
  under a long-standing **$100 per-person, per-year** gift limit; public-pension
  and government-adjacent relationships carry **pay-to-play** sensitivities that
  can make even modest gifts a problem. You usually won't know the exact rule, so
  **default conservative and assume a limit exists.**
- **Avoid cash and cash-equivalents.** Cash, prepaid cards, and most gift cards
  read as compensation and frequently violate policy. Prefer experiences,
  consumables, or specific items.
- **Flag, don't assume, the policy.** Recommend that the sender check **both** their
  own gift policy and the recipient's likely constraints, and note when a category
  (e.g., anything substantial to a public-fund contact) is best avoided entirely.
- **When the value ceiling is tight,** the **give-back** and **modest local /
  consumable** archetypes shine — high class, low risk.

## 5. The dignity / not-too-intimate line

The gift should feel like *attention*, not *surveillance*. Stay on the right side:

- **No body-knowledge gifts** (clothing/shoe sizes, anything fitted) for
  professional relationships.
- **Nothing keyed to their home, routine, or family details** — even if those
  surfaced. A gift that references a spouse or kids by name can feel invasive
  unless the relationship clearly warrants it (a couple's *experience* framed
  around a shared, publicly-stated interest like "you and [partner] love food" is
  usually fine; naming children is not).
- **The mirror test:** if receiving this gift would make the person feel *watched*
  rather than *thought of*, cut it. This is the same dignity test the research
  skill uses — keep them consistent so the whole pipeline stays on the right side
  of the line.

## 6. The disqualifier checklist

Strike any idea that trips one of these before it reaches the shortlist:

- ❌ **Violates a guardrail** from the profile (sober → alcohol; vegan →
  leather/meat; stated dislike).
- ❌ **Built on a stale or contradicted signal** (an interest a newer signal
  replaced).
- ❌ **Low-confidence guess** dressed up as a bold, specific gift — confirm first or
  downgrade to a safe option.
- ❌ **Exceeds the appropriate value / compliance band**, or is cash / a cash-
  equivalent.
- ❌ **Timed onto a pending decision** (looks like influence).
- ❌ **Too intimate / invasive** under the dignity test.
- ❌ **Generic** — branded swag, a generic bottle, a gift card, a fruit basket, "a
  nice pen." Fails the feel-seen test by definition.
- ❌ **Higher-variance categories that need a flag** rather than an automatic cut:
  anything firearm-adjacent, strongly political, religiously specific, or
  appearance-related. Only include with an explicit risk note, and only when the
  signal clearly supports it.

If filtering leaves you thin, that's information: fall back to the thin-profile
handling in `SKILL.md` (lower-risk, still-thoughtful, honest about the limits)
rather than forcing a risky idea through.
