---
name: gift-sourcing
description: >-
  Turn a chosen gift IDEA into a decision-ready purchase: the specific, real,
  buyable product or experience, where to get it, the actual current price
  (checked against budget and compliance), whether it's available in time, how
  to deliver or present it, and a backup if it's out of stock. Use this once
  someone knows roughly WHAT to give and needs to make it real — "where do I buy
  this", "find the actual product", "source this gift", "book this experience",
  "how do I get this to them", "is it in stock". It consumes the Gift Strategist
  output (idea + budget band + open questions + recipient location) but works
  from any concrete gift idea. Trigger for any "make this gift happen" request,
  even when the user doesn't say "sourcing". Crucially, it handles ideas that
  still have OPEN VARIABLES (e.g. fly vs. bass fishing, does he drink) by
  sourcing option-preserving choices rather than guessing. This is the
  procurement step; deciding what to give and why was the Gift Strategist step.
---

# Gift Sourcing

## What this produces

For each gift idea, a **decision-ready sourcing recommendation**:

- the **specific, real product or experience** (named, not a category),
- **where to get it** (a reputable, vetted vendor / outfitter / venue),
- the **actual current price**, checked against the budget and compliance band,
- **availability & lead time** (in stock / bookable / in season / can it arrive
  or be redeemed in time),
- **how to deliver or present it** — especially the B2B reality that you usually
  *don't* have the recipient's home address,
- a **backup** if the first choice falls through,
- and **verified links** (sourcing *is* the "where to buy" step, so real links
  belong here — but only ones you've actually confirmed, never invented).

The previous step (Gift Strategist) decided *what* and *why*. This step makes it
real and ready to buy or book.

## The core principle: buy the option, not the guess

The Gift Strategy will often arrive with **open variables** it couldn't resolve —
and the sender may not know the answer either ("I don't know if he fly-fishes or
bass-fishes, or whether he drinks"). Guessing is how a great idea becomes a wrong
gift. The sourcing move is to **preserve optionality**:

- **Flexible bookings / "you choose" experiences** — book an outfitter or venue
  that accommodates *either* answer, or a session the recipient tailors on the
  day. A guided fishing trip with an outfitter who runs both fly and conventional
  trips makes "fly vs. bass" irrelevant.
- **Gift certificates to a vetted, specific place** — a credit to a single
  excellent local outfitter/restaurant/shop keeps the choice in the recipient's
  hands while still being precise about *where* (the precision lives in the
  curation, not in forcing the variable).
- **Robust picks that work regardless** — a *food-forward* experience lands
  whether or not he drinks; a renowned restaurant works for any palate; quality
  gear that any angler uses sidesteps the discipline question.
- **Or branch cleanly** — when a single option can't cover both cases, present
  "if A → this; if B → that" so the sender can pick the moment they learn the
  answer.

Only resolve an unknown by *more research* when it's genuinely discoverable;
where it isn't (as is often true for private preferences), hedge — don't invent.

## Constraints bite again at the concrete level

Upstream constraints aren't settled just because the strategy cleared them — the
*specific* choice can reintroduce a problem, so re-check at purchase time:

- **Real price vs. band.** The strategy had a *range*; sourcing produces a *number*.
  Re-validate it against budget and the compliance ceiling. A "modest experience"
  that prices out at a luxury number must be downgraded or swapped.
- **Guardrails, re-applied to the actual item.** A "food-forward" pick that turns
  out to be a wine-pairing dinner reintroduces alcohol; a "leather-free" intent
  can sneak back in via materials. Check the concrete product against the
  guardrails again.
- **Quality / taste vetting.** A perfectly-conceived gift sourced from a junky,
  scammy, or cheap-looking vendor undercuts the whole effect. Vet reputation
  (reviews, authenticity, is this a real well-regarded outfitter vs. a tourist
  trap) before recommending.
- **Dignity / delivery intimacy.** Don't source something that requires private
  data you shouldn't have (home address, sizes). Prefer delivery paths that don't.

## The B2B delivery reality

For a prospect or client you almost never have a home address, and office
delivery is hit-or-miss (mailrooms, remote workers). Favor **address-free**
fulfillment, and treat *how it's delivered* as part of sourcing, not an
afterthought:

- **Experience voucher / e-gift the recipient redeems** — emailed or handed over;
  no address needed; they pick the date. Ideal for experiences and many local
  gifts.
- **"I'd like to take you" invitation** — for an experience, offering to book it
  *together* is often the highest-touch B2B move: it deepens the relationship and
  removes shipping entirely.
- **Office delivery to a known work address** — fine for objects, with the note
  enclosed; confirm they're in-office.
- **Reputable gifting/concierge platforms** that let the recipient confirm their
  own shipping details — useful when you have neither address nor an in-person
  occasion. (Choose category by fit; don't force a specific platform.)

## Workflow

### Phase 0 — Ingest the gift idea
Take the Gift Strategist output (or any concrete idea): the idea itself, its
budget band, the **open questions/unknowns**, the **gifting guardrails**, and the
**recipient's location** (critical — experiences and local gifts must be sourced
near *them*, not the sender).

### Phase 1 — Resolve or hedge the unknowns
For each open variable: is it discoverable by research? If yes and it matters,
look. If not (private taste, etc.), pick the **option-preserving** path from the
core principle above. Decide this *before* searching for products, because it
changes what you search for.

### Phase 2 — Find real candidates
Search for the specific product/experience. For anything location-anchored
(experiences, restaurants, local goods), search **near the recipient's location**
and use place/maps lookups to find real, nearby, well-rated options. Pull the
actual vendor, not a generic "you could get a…".

### Phase 3 — Verify
Confirm, from real sources: **current price**, **availability / lead time /
season**, **vendor reputation and quality**, and a **working link**. Don't quote a
remembered price or assume stock — check. If you can't verify a detail, say so.

### Phase 4 — Re-check constraints
Run the concrete choice back through: price vs. band/compliance, guardrails,
quality bar, dignity/delivery. Swap it if it now trips something.

### Phase 5 — Solve delivery, personalization, and the note
Choose the delivery path (address-free where possible), note any **personalization**
(engraving, gift message, packaging), confirm it can **arrive/redeem in time**, and
state how to **attach the note** from the strategy.

### Phase 6 — Produce the sourcing sheet
Deliver a **lead recommendation + one backup** per idea — decision-ready, not a
dump of twelve links. The sender should be able to act in one read.

---

## Output schema

```markdown
# Sourcing — [Gift idea] for [Name]
Budget/compliance band: [from strategy] · Recipient location: [city/region]
Unknowns carried in: [open variables] → handled by: [resolve / hedge / branch]

## Recommended
- The specific buy: [exact product or experience, named]
- Vendor / where: [name] — [why it's reputable/vetted]
- Price (verified): [$ actual] → vs. band: [pass / flag]
- Availability & lead time: [in stock / bookable / season; arrives-or-redeems by]
- How it handles the unknown(s): [the option-preserving choice, in one line]
- Delivery / presentation: [address-free voucher / take-them / office]; note: "[the note]"
- Personalization: [engraving / gift message / packaging, if any]
- Link: [verified URL]
- Flags / confidence: [anything to double-check]

## Backup
- [second verified option, same fields in brief — in case of stock/booking/price issues]

## If you later learn [the unknown]
- [clean branch: if A → this; if B → that] (only if a single option couldn't cover both)

## Notes
- [delivery timing, who to call, compliance reminder to check both parties' policies, etc.]
```

---

## Worked example (abridged)

**Idea:** "a guided fishing morning in the Hill Country." **Band:** modest
experience. **Recipient:** Fredericksburg, TX. **Unknown:** fly vs. bass — sender
doesn't know.

- **Resolve or hedge?** Discipline isn't publicly known → **hedge.** Source a
  reputable local outfitter that runs *both* fly and conventional trips, or a gift
  certificate to one — "fly vs. bass" becomes the guest's call.
- **Find & verify:** search Hill Country / Guadalupe-area guides near
  Fredericksburg; confirm a well-reviewed outfitter, the **actual half-day rate**,
  and that they're **booking the relevant season**, plus a working link.
- **Re-check:** rate sits inside the modest band ✓; no guardrail issue ✓;
  outfitter is reputable, not a tourist trap ✓.
- **Deliver:** a **gift certificate / booking voucher** (no home address needed),
  or offer to **book it together**; enclose the strategy's note.
- **Sheet:** lead = [the vetted outfitter, with price + link + how to gift];
  backup = a second area guide; plus the timing to book before the season fills.

The discipline question never has to be answered to send a great gift.

---

## Where to go deeper

- **`references/sourcing-and-verification.md`** — search & place-lookup tactics for
  finding the real thing near the recipient, vetting vendor quality/authenticity,
  getting an accurate *current* price, checking availability/season, link
  discipline, and the full toolkit of option-preserving buys for open variables.
  Read during Phases 1–4.
- **`references/delivery-and-logistics.md`** — address-free delivery, the
  take-them play, office delivery, vouchers/e-gifts, personalization, attaching
  the note, timing, and re-checking compliance/guardrails on the concrete item.
  Read during Phases 4–6.
