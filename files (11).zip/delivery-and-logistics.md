# Delivery & Logistics

How to actually get the gift to the recipient — and re-check the concrete choice
against the constraints. Read during Phases 4–6. Getting the *thing* right and
then fumbling delivery wastes the whole effort, so treat this as part of sourcing.

## Contents
1. Delivery paths (B2B-first, address-aware)
2. Personalization and packaging
3. Attaching the note
4. Timing
5. Re-checking compliance and guardrails on the concrete item

---

## 1. Delivery paths (B2B-first, address-aware)

You usually won't have a prospect's or client's home address, and office delivery
can misfire. Pick the path that fits what you actually know:

- **Experience voucher / e-gift the recipient redeems** — emailed or handed over;
  **no address required**; they choose the date. Best default for experiences and
  many local gifts.
- **"I'd like to take you" invitation** — for an experience, offering to book and
  go *together* is often the strongest B2B move: it turns the gift into shared
  time and removes shipping entirely. Frame it warmly, with no business ask
  attached.
- **Office delivery to a known work address** — workable for objects; confirm the
  recipient is in-office (not fully remote), and enclose the note. Watch for
  mailroom handling of perishables.
- **Concierge / gifting platform that collects the recipient's own details** —
  when you have neither a home address nor an in-person occasion, a reputable
  platform can let the recipient confirm shipping themselves. Choose by fit; don't
  default to one because it's familiar.
- **Personal / established relationships** — a home address may be appropriate;
  the dignity test still applies (don't use an address you obtained through
  research the recipient wouldn't expect you to have).

## 2. Personalization and packaging

Small touches raise the effort cue without raising spend:

- **Engraving / monogram** for objects — confirm it's offered and fits the lead
  time (personalization often adds days).
- **Gift message / curated packaging** — many vendors include a handwritten-style
  card; use it for the note.
- Keep personalization **tasteful and not over-familiar** for professional
  relationships (initials and a clean message, not anything intimate).

## 3. Attaching the note

The note from the strategy is half the impact — make sure it actually travels with
the gift:

- For **vouchers/e-gifts**, put the note in the email/message body or on the
  printed certificate.
- For **shipped objects**, use the vendor's gift-message field or enclose a card.
- For **"take them"** experiences, the note becomes the invitation itself —
  specific, warm, no ask.
- Carry the note's wording **verbatim** from the strategy; don't dilute the
  specific reference that makes it land.

## 4. Timing

- Map **lead time + personalization + shipping** (or booking horizon) against any
  occasion or deadline; build in slack.
- For **seasonal experiences**, book or buy before the window fills.
- Avoid arrival **on top of a pending decision** (the strategy's timing rule still
  applies at the moment of delivery, not just ideation).

## 5. Re-checking compliance and guardrails on the concrete item

The specific choice can reintroduce a problem the idea didn't have — so run a final
pass:

- **Real price** sits inside budget **and** under the compliance ceiling? If a
  policy limit applies (common in regulated/financial relationships), the *actual*
  number is what gets checked — not the band.
- **Guardrails** still clear on the concrete item? (A "food-forward" booking that's
  actually a wine dinner reintroduces alcohol; a material you ruled out can return
  via the specific product.)
- **No cash-equivalent** crept in (a generic prepaid/marketplace card instead of a
  specific-venue certificate)?
- **Delivery** doesn't rely on private data you shouldn't have, and isn't
  timed onto a live decision?
- **Reminder to surface to the sender:** check **both** parties' gift policies
  before sending — sourcing can flag the likely ceiling, but the sender confirms.

If the final pass trips something, switch to the backup rather than shipping a
problem.
