---
name: sherlock-ai
description: >-
  Conduct deep, evidence-based research into one named person's genuine
  interests, passions, hobbies, and pursuits — across the open web, published
  interviews, podcasts, conference talks, company bios, and public social
  posts — and assemble a structured, ranked Interest Profile for
  relationship-building and personalized gifting. Use this skill whenever the
  user names an individual (usually with their company) and wants to understand
  what that person actually cares about, find personal or non-obvious interests,
  prep for high-touch outreach, or set up a gift that makes the recipient feel
  seen. Trigger for requests like "research [name]", "what is [name] into",
  "find personal interests for [name] at [company]", "build a profile on this
  prospect", "dig up everything on [name]", or any account/contact
  personalization task — even if the user never says "Sherlock". This is the
  research-and-synthesis step; choosing the actual gift is a separate downstream
  step that consumes the Interest Profile this skill produces.
---

# Sherlock AI

## What this skill produces

A single deliverable: an **Interest Profile** of one named person — a ranked,
evidence-backed map of what they genuinely care about (hobbies, passions,
pursuits, causes, affiliations, tastes), each item tied to a real source and a
date, with a recency tier and a confidence level.

The Interest Profile exists to power *thoughtful, specific* relationship-building
— the kind of gift or gesture that makes someone feel seen rather than marketed
to. Selecting the actual gift is a separate downstream step; Sherlock's only job
is to find the signal and structure it cleanly so that step has something real
to work with.

## What "good" looks like (read this first)

The bar is **not** "list some plausible interests." A profile that says *"enjoys
golf, wine, and travel"* is a failure even if it's accurate, because everyone
enjoys those and a gift built on them lands as generic.

The bar is: surface the **specific, current, well-evidenced** things this person
cares about, so a gift built on them feels like it came from someone who'd been
paying attention. Compare:

- ❌ "Likes chess."
- ✅ "Active chess player — joined the Marshall Chess Club this spring (LinkedIn
  post, Mar 2026), repeatedly references the Najdorf Sicilian, mentioned
  re-reading a Kasparov book on a podcast (Apr 2026)." → enables a gift like a
  signed edition or a lesson with a titled player, not a plastic set.

Three things separate a hit from a miss, and the whole workflow optimizes for
them:

1. **Specificity** — the *particular* author, team, opening, trail, bike, dish,
   cause. Generic categories are weak; the specific detail inside them is the
   gold.
2. **Recency** — what they're into *now*. People change. A signal from last
   month beats one from three years ago, and a recent signal can *cancel* an old
   one (see Phase 4).
3. **Evidence** — every claim traces to a real, dated, public source. No
   inference dressed up as fact, no fabrication. A confident-sounding profile
   built on guesses is worse than a thin honest one.

## Operating principles

**Legitimate access only — and it's also what works.** Use public, indexable
information and permitted access paths. Do **not** attempt to bypass logins,
paywalls, robots.txt / anti-scraping protections, rate limits, CAPTCHAs, or any
platform's terms of service. This is a hard line, but it's also the *practical*
line: LinkedIn, Instagram, and Facebook actively block automated access (verified
— a direct fetch returns a robots-disallowed error), bypassing them gets accounts
and API keys banned and creates real legal exposure, and scraped data behind a
wall tends to be stale or mangled anyway. When a channel is walled, the high-yield
move is to **route around it** — the search index surfaces a surprising amount of
public profile text and posts, and the person's own published material
(interviews, talks, articles, bios) is openly fetchable. "If you can't get in,
figure it out" means *find another public door*, never *pick the lock*.

**Evidence discipline.** Separate three things and never let them blur: a
**stated fact** (the person said it), an **observed signal** (something public
that strongly implies an interest — e.g., they speak at a niche conference every
year), and an **inference** (your reasoning from indirect cues). Label which is
which. Every entry in the final profile cites a source with a date. If you can't
source it, it doesn't go in the profile — at most it becomes an "open lead to
verify."

**Recency wins.** Weight fresh signals far above old ones, and actively look for
*change* — a new city, a new role, a hobby that replaced an old one, a lifestyle
shift. A newer signal supersedes an older contradictory one (Phase 4). Old
interests aren't deleted; they move to a "background / rapport" section, useful
for conversation but not for a current gift.

**Specificity over popularity.** Always push past the category to the detail.
"Reads" → which authors/genres. "Into fitness" → running? lifting? a specific
race they're training for? "Sports fan" → which team (and a public photo in a
cap is a legitimate hint — see the playbook). The narrower and more personal the
signal, the better the eventual gift.

**Data minimization and purpose limitation.** Collect only what serves the
purpose — *understanding interests for a thoughtful, welcome gesture.* This is a
relationship tool, not a surveillance dossier, and the scope reflects that.

## The no-go list

Do not collect, infer, compile, or include any of the following, even if it
surfaces and even though it's technically "about the person." None of it serves
gifting, and gathering it turns a thoughtful tool into a creepy one:

- Home address, neighborhood-level location, daily routines, or current
  whereabouts — anything that helps someone *find* them physically.
- Personal phone number, personal email, or other off-channel contact details.
- Family members', partners', or children's names, schools, images, or details.
- Financial details, net worth estimates, property records, legal/court records.
- **Sensitive personal characteristics** — health or medical conditions,
  mental-health status, addiction/recovery status, religion, sexual orientation,
  gender identity, political affiliation, race or ethnicity, disability. Do not
  infer these from cues and do not record them as attributes.

**The one narrow, one-directional exception — "gifting guardrails."** Sometimes a
person has *publicly and unambiguously stated* something that should stop you from
making a tone-deaf gift: they're sober, vegan, vegetarian, observant of a dietary
law, or have a stated allergy. Capture these **only** as a *"things to avoid"*
guardrail — never as a profiled trait, never inferred from indirect signals. The
purpose is purely to prevent a harmful misstep (don't send wine to someone in
recovery; don't send a leather goods set to someone who's publicly vegan). You are
recording a *constraint on the gift*, not a fact about the person's body, beliefs,
or history. If it isn't stated plainly and publicly by the person, leave it out.

**The dignity test.** A finished Interest Profile should be something you'd be
comfortable showing the person themselves over coffee. If an entry would make them
feel watched or exposed rather than appreciated, it doesn't belong — drop it.

---

## Workflow

Move through these phases in order. Scale the depth to the person's public
footprint: a frequent conference speaker with a podcast and an active feed
warrants a deep sweep; someone with a thin footprint warrants an honest, shorter
profile rather than padding with guesses.

### Phase 0 — Lock the identity

Common names and same-company namesakes are the number-one source of a ruined
profile (you blend two people and recommend a gift for the wrong life). Before
attributing anything, pin down *which* person this is using at least two
corroborating anchors: full name + current company + role, plus location, a photo,
or a unique handle. Carry these anchors into every later search so you're matching
the right individual. If you genuinely can't disambiguate, say so rather than
guessing.

### Phase 1 — Channel sweep

Search broad, then narrow, working through the channels in
`references/channel-playbook.md`. The goal is *coverage*: professional bio, their
own published words (posts, articles, talks, podcast appearances), press and
interviews, and niche/hobby footprints. Run a separate, targeted search per
channel and per promising lead rather than one mega-query — combined queries
return shallow results for everything. Read the playbook for the channel-by-
channel tactics, including how to handle walled platforms via the search index and
alternative sources.

### Phase 2 — Harvest and read deeply

Don't profile from search snippets alone. When a source looks rich — a podcast
appearance, a long interview, a personal blog, a conference talk, a substantive
post — fetch and actually *read* it. The best, most specific signals (an offhand
"I've gotten really into X lately") live in the body of long-form content, not in
titles. For audio/video, see the playbook's transcript tactics: search for an
existing transcript or show notes, and mine quotes that have been written up
elsewhere. Capture the source URL and a date for everything you pull from.

### Phase 3 — Extract signals

From what you've read, pull candidate interests. For each, note: what it is, the
exact evidence (a short quote or description), the source, the date, and whether
it's a stated fact, an observed signal, or an inference. Push every candidate
toward specificity — record the particular detail, not just the category. The
scoring rubric and a fuller taxonomy of signal types live in
`references/signal-taxonomy.md`.

### Phase 4 — Resolve recency and conflicts

Now reconcile the timeline. Sort signals into recency tiers (current /
recent / background — defined in the taxonomy). Where two signals conflict or
one clearly replaced another, the **newer supersedes**:

- "Loved craft beer" (2022) + "two years sober, feeling great" (2026) → the beer
  signal is dead; sobriety becomes a *gifting guardrail* (avoid alcohol). Sending
  beer here would be actively harmful, which is the whole point of doing this.
- "Ran marathons" (2023) + "first triathlon this season" (2026) → endurance sport
  is current, but the *triathlon* is the live, specific signal; marathon is
  background.
- Old city in a bio + recent posts geotagged in a new city → update the location
  context; don't recommend something tied to the old place.

Demote superseded items to "background"; don't delete them (they're still useful
for rapport).

### Phase 5 — Score and rank

Rank the surviving interests by gift-worthiness, combining **recency ×
engagement depth × specificity × confidence** (rubric in the taxonomy). A recent,
deeply-engaged, specific, well-sourced interest tops the list; a stale, one-off,
vague, low-confidence mention sinks. Aim to surface a handful of genuinely strong
candidates rather than an exhaustive but flat list.

### Phase 6 — Assemble the Interest Profile

Write it up in the exact structure below. Be honest about confidence and gaps —
a downstream gift step is far better served by "three strong signals and two
weak leads, here's the evidence" than by a falsely confident wall of guesses.

### Stopping rule

Stop when new searches stop yielding new signal — when you're seeing the same
facts recycled across sources, or when remaining queries would only push into the
no-go list. More searching past that point doesn't improve the gift; it just
drifts toward surveillance. A thin-but-honest profile on a low-footprint person is
the correct output, not a failure to paper over.

---

## Output: the Interest Profile

Use this exact structure so the downstream gift step can consume it reliably:

```markdown
# Interest Profile — [Full Name]
Role / Company: [title] at [company]
Identity anchors: [the corroborating details used to confirm this is the right person]
Researched: [date] · Sources reviewed: [N] · Overall confidence: [High / Medium / Low]

## Top interests (ranked, gift-ready)
1. **[Specific interest]**
   - Evidence: "[short quote or description]" — [source], [date]
   - Type: [stated fact / observed signal / inference]
   - Recency: [current / recent / background]
   - Engagement: [passing mention / recurring theme / active practitioner]
   - Specificity: [the specific detail that makes this giftable]
   - Confidence: [H / M / L]
   - Possible angle: [one line — note that detailed gift selection is a separate step]
2. ...

## Gifting guardrails — things to AVOID
- [Only if publicly + unambiguously stated by the person. e.g., "Publicly sober
  (post, 2026) → no alcohol." / "Vegan (bio) → no leather, meat, or animal
  products."] If none found, write "None identified."

## Background / past interests (rapport, not gifting)
- [Superseded or stale items — useful for conversation, not for a current gift.]

## Open leads to verify
- [Low-confidence or unsourced hunches worth confirming before acting on.]

## Sources
- [URL] — [what it provided] — [date]
- ...
```

---

## Worked example (abridged)

**Request:** "Research Dana Okafor, a partner at Meridian Growth Partners — find
something personal I could send."

**How it goes:** Phase 0 confirms identity via name + firm + a headshot matching
the firm's team page and a conference bio. Phase 1's sweep finds: the firm bio
(with a "fun fact" line), two podcast appearances, a personal X account, and a
guest article. Phase 2 reads the podcasts — in one, she mentions she "got back
into pottery during a sabbatical and now has a little home studio" (Feb 2026), and
in an older one references training for a marathon (2023). The firm "fun fact"
says she's a competitive chili cook. Her recent posts are mostly about pottery and
ceramics studios she's visited.

**Resolution & output (excerpt):**

- Top interest #1: *Pottery / ceramics* — recurring + active, recent (2026),
  specific (home studio, hand-building, follows specific studios) → confidence
  High. Strong, current, specific: the headline.
- Top interest #2: *Competitive chili cooking* — distinctive and memorable, but
  older/low-frequency → confidence Medium.
- Background: *marathon running* — a 2023 signal with nothing recent; keep for
  rapport, don't build a gift on it.
- Guardrails: none stated.

The pottery signal is the win precisely because it's specific and current — it
points toward something like a gift certificate to a renowned ceramics studio or a
set of artisan tools, which lands as "you actually listened," versus a generic
desk gift.

---

## Where to go deeper

- **`references/channel-playbook.md`** — channel-by-channel tactics: how to mine
  LinkedIn / X / Instagram / Facebook within the rules, how to find and read
  podcast and video content (transcripts, show notes), where the high-yield
  "fun fact" sources hide, niche/hobby footprints (clubs, races, reviews,
  contributions), and how to use public photos as low-confidence hints. Read it
  during Phases 1–2.
- **`references/signal-taxonomy.md`** — what counts as a signal, the recency
  tiers, the engagement-depth and specificity scales, the scoring rubric, and
  detailed handling of the sensitive-attribute boundary and gifting guardrails.
  Read it during Phases 3–5.
