---
name: gift-strategist
description: >-
  Turn a person's researched interests into a ranked shortlist of high-impact
  gift IDEAS — the kind that make the recipient feel genuinely seen ("how did
  they know?") instead of politely re-gifted. Use this skill whenever someone
  has a profile, notes, or even a few facts about a person and wants to decide
  WHAT to give: a prospect or client gift, a thank-you, a relationship gesture,
  a teammate or colleague gift, or any "what should I send [name]?" question. It
  pairs with and consumes the Sherlock AI Interest Profile, but works from any
  set of interest notes. Trigger for "what gift should I send", "gift ideas for
  [name]", "help me pick something for this client/prospect", "what would make
  [name] say wow", or any gifting decision — even when the user never says "gift
  strategist". This skill decides what to give and why, and what to say with it.
  It deliberately stops short of WHERE to buy it — sourcing specific products,
  vendors, and links is a separate downstream skill.
---

# Gift Strategist

## What this produces

A ranked shortlist of gift **ideas** (not specific products) — usually 4–6, with
one clear top pick — each tied to a specific thing about the person, plus the
reason it will land, a suggested note to send with it, a budget band, and an
appropriateness check.

The job is to answer **"what gift makes the most impact?"** — the *what* and the
*why*, and *what to say*. Finding the exact product, vendor, or link is the
separate **sourcing** step downstream. Stop at: idea + rationale + rough budget +
the note. Don't name SKUs or retailers here.

## The outcome we're optimizing for

The reaction is specific: *"holy shit — how did they know?"* That feeling is not
bought with money; a $400 generic gift produces a polite thank-you, while a $60
gift aimed dead-center at something the person actually cares about produces
delight. We are optimizing for **the sense of being seen**, not for spend.

The litmus test for every idea — the **"feel-seen test"**: *could the recipient
name the exact thing about themselves this gift came from?* If yes, it's a
contender. If it could have been sent to any executive on earth, cut it.

## The five levers of "how did they know?"

Every strong idea pulls one or more of these. Use them to generate and to score
(rubric in `references/impact-playbook.md`):

1. **Precision** — maps to a *specific, named* detail, not a category. Not "likes
   the outdoors" → a generic gift card, but "fishes the Hill Country" → something
   a Hill Country angler would love. The narrower the fit, the louder the signal.
2. **Synthesis** — connects *two or more* signals into one gift. Nobody expects
   their dots to be connected; doing it is the strongest "how did they know?"
   move there is (outdoors + food + their new town → one experience that is all
   three).
3. **Effort cue** — visibly required thought. The accompanying note that names the
   specific thing is half the impact; a perfect gift with a blank card lands at a
   fraction of its potential (see the note-craft section in the playbook).
4. **Usability** — fits something they *actively do*, so the gift enters their
   real life instead of a drawer. Weight active practice over aspiration.
5. **Tasteful surprise** — elevated, hard-to-find, or experiential — something they
   wouldn't buy themselves — without tipping into excess (see constraints).

## Hard constraints — apply these BEFORE you ideate

A gift that breaks one of these doesn't just score low; it backfires. Filter the
signals and cap the options *first*, then create within what's left. Full
checklist in `references/appropriateness-and-constraints.md`.

- **Guardrails (the profile's "avoid" list) are vetoes.** Sober → no alcohol.
  Vegan → no leather/meat. A stale or contradicted interest is dead (don't gift
  beer to someone who got sober). Getting this wrong turns a gesture into an
  insult.
- **Appropriateness and value band — this is the big one in B2B.** An expensive
  gift can *hurt*: it can breach the recipient's gift-acceptance policy (forcing
  them to decline or report it), read as a quid-pro-quo, or simply make them
  uncomfortable. Tasteful and well-aimed beats lavish every time. Default to a
  modest, defensible band; avoid cash and cash-equivalents (incl. most gift
  cards); never time a gift to land on top of a pending decision. When in doubt,
  favor a shared experience or a thoughtful modest item over an expensive object.
- **Dignity / not-too-intimate.** The gift should feel like attention, not
  surveillance. Nothing that requires knowing their body (clothing sizes), their
  home, or private family details. If an idea would make them feel *watched*
  rather than *appreciated*, cut it. (This is the same dignity test the research
  skill applies — keep it consistent.)
- **Recency and confidence.** Build on current, well-evidenced interests. A
  low-confidence or years-old signal is a weak foundation for a bold gift —
  either confirm it first or choose something lower-risk.
- **Anti-generic.** Auto-reject the category gifts that signal *zero* thought:
  branded swag, a generic bottle of wine, a gift card, "a nice pen," a fruit
  basket. If it fails the feel-seen test, it's out — no matter how "safe."

## Workflow

### Phase 0 — Ingest the profile

Take the **Sherlock AI Interest Profile** (or whatever interest notes exist) and
pull: the ranked interests with their recency/specificity/confidence, the
**gifting guardrails**, and the background/synthesis notes. If you only have a
couple of loose facts, that's fine — just calibrate ambition to how much real
signal you have (see thin-profile handling below).

### Phase 1 — Establish context

Three things materially change the right gift. If they aren't known, ask (these
are quick to answer and worth it); if you're proceeding without them, **state the
assumptions you're making** so they're easy to correct:

- **Relationship & who's sending** — vendor → prospect/client, peer, manager →
  report, founder → investor, friend. This sets both tone and the value ceiling.
- **Occasion & timing** — first touch, a thank-you, a closed deal, a holiday, no
  occasion (relationship warming). Avoid gifting into a live decision.
- **Budget band & compliance** — the spend range, and any gift-policy limits on
  either side. In regulated/financial contexts, default conservative.

See `references/appropriateness-and-constraints.md` for how each lever shifts the
recommendation.

### Phase 2 — Filter and rank the signals

Drop anything that hits a guardrail, is stale, or is low-confidence. Rank what
remains by *giftability* = recency × engagement depth × specificity × confidence
(the same factors the profile already scored, now viewed through "can I build a
great gift on this?"). A specific, current, active-practice interest is your best
raw material.

### Phase 3 — Ideate across archetypes (force variety)

Don't generate five versions of the same object. Deliberately spread ideas across
the gift **archetypes** (catalog in the playbook), because *form* drives impact as
much as topic:

- **Experience** (a guided outing, lesson, tasting, tickets) — often the highest
  impact: memorable, shareable, hard to re-gift.
- **Elevated version of their thing** (premium gear/tool for a hobby they do).
- **Curated / hard-to-find object** (a signed book, an artisan piece tied to the
  interest).
- **Consumable tied to taste** (specific food/drink — subject to guardrails).
- **In-their-backyard / local** (ties to their city, region, or community).
- **Give-back** (a donation or membership to a cause they care about, in their
  name) — classy and compliance-safe.
- **Handmade / personal** (something curated or made specifically for them).

### Phase 4 — Score and disqualify

Rate each candidate on the five levers and strike any that trip a hard
constraint. Prefer ideas that pull *multiple* levers — especially synthesis.

### Phase 5 — Rank and shape the shortlist

Deliver a focused set (~4–6), not a catalog — a long list signals low effort and
dilutes the strong ideas. Give it shape:

- **One clear top pick** (usually the synthesis/experience idea).
- A **safe pick** (lower variance, broadly resonant, still specific).
- A **bold pick** (higher upside, flag the risk).
- Optionally a **give-back** (zero-compliance-risk classy option).

### Phase 6 — Write the hook and the note

For each idea, write the **hook** (the one-line connection to the specific signal
— this is the "how did they know") and a **suggested note** to send with it. The
note is not an afterthought; it's where the effort cue lives. Keep it short, name
the specific thing, and don't explain the research (see note-craft in the
playbook). A great gift with a generic card underperforms a good gift with a
perfect one.

### Thin-profile handling

If the signal is weak or generic, don't fake a bold, specific gift on a guess —
that's how you get it wrong. Pivot to lower-risk-but-still-thoughtful: a quality
consumable, an experience tied to their city, or a give-back, and say plainly that
precision is limited and what would sharpen it. Honest and good beats confident
and wrong.

---

## Output schema

Use this structure:

```markdown
# Gift Strategy — [Name]
Context assumed: [relationship] · [occasion/none] · [budget band] · [compliance note]
Source: [Interest Profile / notes used]

## Top pick — [idea title]
- The gift (idea, not a product): [what it is]
- Maps to: [the specific signal(s)] → [why this is the "how did they know"]
- Levers: [which of the five it pulls]
- Why it lands: [1–2 sentences]
- Suggested note: "[short, specific, warm]"
- Budget band: [$ range] · Appropriateness: [check / any caveat]
- Confidence: [H/M/L] + any "confirm first" caveat

## Also strong
2. **[Safe pick]** — [idea] · maps to [signal] · note: "[…]" · [$band] · [why]
3. **[Bold pick]** — [idea] · maps to [signal] · note: "[…]" · [$band] · ⚠️ [the risk]
4. **[Give-back / local]** — [idea] · maps to [signal] · [$band] · [why it's classy]

## Skip these (and why)
- [tempting-but-generic or guardrail-tripping ideas, named so they don't resurface]

## To sharpen (hand-off to sourcing + open questions)
- [what to confirm before buying] · [note that product/vendor selection is the next step]
```

---

## Worked example (abridged)

**Profile:** a prospect who "fishes the Hill Country," "loves food and travel with
his wife," and is "putting down roots in his new town"; no guardrails. **Context:**
vendor → prospect, no occasion, modest budget, regulated/financial so
compliance-aware.

- **Top pick (synthesis + experience):** a guided fly-fishing half-day on the
  local river. Maps to fishing **and** the new-town/outdoors signal → unmistakably
  personal. Note: *"Heard you've been exploring the area since the move — figured
  the river deserved a proper introduction. Tight lines."* Modest, experiential,
  not cash, clearly a relationship gesture. Caveat: confirm he fishes that *kind*
  of water before booking.
- **Safe pick:** a beautifully made fly box or polarized sunglasses for the water —
  usable, modest, on-target.
- **Bold pick:** a sporting-clays outing — high "wow," but flag firearm-adjacent
  gifts as higher-variance (recipient/firm sensitivity); only if shooting is
  clearly central. ⚠️
- **Skip:** a generic bottle of wine (fails feel-seen; also don't assume he
  drinks), branded company swag, a gift card.

The fly-fishing experience wins because it pulls precision + synthesis +
usability + tasteful surprise at once, *and* the note makes the connection
explicit. Which guide service to book is the sourcing step's job.

---

## Where to go deeper

- **`references/impact-playbook.md`** — the five levers in depth with how to score
  each, the full gift-archetype catalog (with examples mapped to signals), and the
  craft of the accompanying note. Read during Phases 3–6.
- **`references/appropriateness-and-constraints.md`** — relationship & occasion
  calibration, B2B value/compliance bands and red flags, the dignity / not-too-
  intimate line, and the complete disqualifier checklist. Read during Phases 1–2
  and again before finalizing.
