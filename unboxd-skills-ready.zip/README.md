# UNBOXD skills ready for repo upload

Copy the `skills/` folder into the root of the UNBOXD repo.

Core workflow files:
- skills/sherlock-ai.md
- skills/signal-taxonomy.md
- skills/appropriateness-and-constraints.md
- skills/gift-strategist.md
- skills/impact-playbook.md
- skills/gift-sourcing.md
- skills/sourcing-and-verification.md
- skills/delivery-and-logistics.md

Reference only for later search-channel work:
- skills/reference/channel-playbook.md

Do not wire `channel-playbook.md` into the MVP workflow until a real web-search provider is configured.
